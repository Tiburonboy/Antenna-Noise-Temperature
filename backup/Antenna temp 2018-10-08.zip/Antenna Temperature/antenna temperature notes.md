Antenna Temperature Notes
====
Last update: 1 Oct 2018  

for code debugging and validation, look array tool code.

need to use AF and G to calculate array gain and beamwidth  
need to find an example to check restults  

need to fix hex array generation. need to rotate orientation and overall aspect is wrong  

make 3D plots of array pattern using matplotlib or mayavi  
https://docs.enthought.com/mayavi/mayavi/  

plot AF using u and v  

need to get Raytheon's reference for T sky  


what about out of band responce?   


The effective noise temperature of the antenna TA is not its
physical temperature but accounts for all the noise, including sky
noise and noise of terrestrial origin, that appears at the output
terminals of the antenna, The term sky noise includes noise emitted
by the constituents of of the Earth’s atmosphere, namely gases,
hydrometers, and any other matter such as dust.

, namely gases,
hydrometers, and any other matter such as dust. 

It also” includes
extraterrestrial noise emitted by the Sun, Moon, planets$ and
universe, including the 2.7 K component which fills space,
Terrestrial noise may be picked up by the side lobes or as a result
of antenna spillover and blockage, in the case of the earth-station
antenna. T

The estimates of radio noise levels given here are for the background noise level in the
absence of other signals, whether intentionally or unintentionally radiated, so that noise or signals
due to unwanted co-channel transmissions or due to spurious emissions from individual transmitting
or receiving systems are not considered in this Recommendation.  

# radiative transfer program
curves are calculated using a radiative transfer program
https://en.wikipedia.org/wiki/Radiative_transfer  
Radiative transfer is the physical phenomenon of energy transfer in the form of electromagnetic radiation. The propagation of radiation through a medium is affected by absorption, emission, and scattering processes. The equation of radiative transfer describes these interactions mathematically. Equations of radiative transfer have application in a wide variety of subjects including optics, astrophysics, atmospheric science, and remote sensing. Analytic solutions to the radiative transfer equation (RTE) exist for simple cases but for more realistic media, with complex multiple scattering effects, numerical methods are required. The present article is largely focused on the condition of radiative equilibrium.[1] [2]  

# Beer–Lambert law in the atmosphere
https://en.wikipedia.org/wiki/Beer%E2%80%93Lambert_law  
This law is also applied to describe the attenuation of solar or stellar radiation as it travels through the atmosphere. In this case, there is scattering of radiation as well as absorption. The optical depth for a slant path is τ′ = mτ, where τ refers to a vertical path, m is called the relative airmass, and for a plane-parallel atmosphere it is determined as m = sec θ where θ is the zenith angle corresponding to the given path. The Beer–Lambert law for the atmosphere is usually written  

{\displaystyle T=e^{-m(\tau _{\mathrm {a} }+\tau _{\mathrm {g} }+\tau _{\mathrm {RS} }+\tau _{\mathrm {NO_{2}} }+\tau _{\mathrm {w} }+\tau _{\mathrm {O_{3}} }+\tau _{\mathrm {r} }+\ldots )},} T=e^{{-m(\tau _{{\mathrm  {a}}}+\tau _{{\mathrm  {g}}}+\tau _{{\mathrm  {RS}}}+\tau _{{\mathrm  {NO_{2}}}}+\tau _{{\mathrm  {w}}}+\tau _{{\mathrm  {O_{3}}}}+\tau _{{\mathrm  {r}}}+\ldots )}},
where each τx is the optical depth whose subscript identifies the source of the absorption or scattering it describes:

where each τx is the optical depth whose subscript identifies the source of the absorption or scattering it describes:

a refers to aerosols (that absorb and scatter);
g are uniformly mixed gases (mainly carbon dioxide (CO2) and molecular oxygen (O2) which only absorb);
NO2 is nitrogen dioxide, mainly due to urban pollution (absorption only);
RS are effects due to Raman scattering in the atmosphere;
w is water vapour absorption;
O3 is ozone (absorption only);
r is Rayleigh scattering from molecular oxygen (O2) and nitrogen (N2) (responsible for the blue color of the sky);
the selection of the attenuators which have to be considered depends on the wavelength range and can include various other compounds. This can include tetraoxygen, HONO, formaldehyde, glyoxal, a series of halogen radicals and others.
m is the optical mass or airmass factor, a term approximately equal (for small and moderate values of θ) to 1/cos θ, where θ is the observed object's zenith angle (the angle measured from the direction perpendicular to the Earth's surface at the observation site). This equation can be used to retrieve τa, the aerosol optical thickness, which is necessary for the correction of satellite images and also important in accounting for the role of aerosols in climate.

# Atmospheric radiative transfer codes
An Atmospheric radiative transfer model, code, or simulator calculates radiative transfer of electromagnetic radiation through a planetary atmosphere, such as the Earth's.

At the core of a radiative transfer model lies the radiative transfer equation that is numerically solved using a solver such as a discrete ordinate method or a Monte Carlo method. The radiative transfer equation is a monochromatic equation to calculate radiance in a single layer of the Earth's atmosphere. To calculate the radiance for a spectral region with a finite width (e.g., to estimate the Earth's energy budget or simulate an instrument response), one has to integrate this over a band of frequencies (or wavelengths). The most exact way to do this is to loop through the frequencies of interest, and for each frequency, calculate the radiance at this frequency. For this, one needs to calculate the contribution of each spectral line for all molecules in the atmospheric layer; this is called a line-by-line calculation. For an instrument response, this is then convolved with the spectral response of the instrument. A faster but more approximate method is a band transmission. Here, the transmission in a region in a band is characterised by a set of pre-calculated coefficients (depending on temperature and other parameters). In addition, models may consider scattering from molecules or particles, as well as polarisation; however, not all models do so.  


JCSDA Projects - Community Radiative Transfer Model  
https://www.jcsda.noaa.gov/projects_crtm.php  


# clouds

The principal types of naturally occurring radio noise, generated
externally to the receivers of telecommunication systems, are the
noise of lightning discharges (commonly referred to as atmospheric
noise), cosmic noise, thermal radiation from the atmosphere and
nearby terrain and objects, and noise from the Sun, Moon, and
distant lanets.
E
Noise from lightning predominates for frequencies
below a out 20 MHz, and cosmic noise tends to be most important
between about 20 and 1000 MHz. Above 1000 MHz, atmospheric
thermal noise tends to predominate, when the antema points into
space and not towards the Sun or other discrete source. Noise from lightning occurs mainly at frequencies below the range of this
handbook and cosmic noise is considered in Sec. 7.3. Attention is
directed in this section tc) atmospheric thermal noise.

The mechanism believed to be responsible for most non-thermal
emission is synchrotrons radiation. This form of radiation occurs
when high velocity electrons follow spiral paths in magnetic fields
(Jackson, 1962; Kraus. 1986).


Cygnus A (3C 405) is a radio galaxy, and one of the strongest radio sources in the sky. It was discovered by Grote Reber in 1939. In 1951, Cygnus A, along with Cassiopeia A, and Puppis A were the first "radio stars" identified with an optical source.

Radio galaxies and their relatives, radio-loud quasars and blazars, are types of active galaxy that are very luminous at radio wavelengths, with luminosities up to 1039 W between 10 MHz and 100 GHz.[1] The radio emission is due to the synchrotron process. The observed structure in radio emission is determined by the interaction between twin jets and the external medium, modified by the effects of relativistic beaming. The host galaxies are almost exclusively large elliptical galaxies. Radio-loud active galaxies can be detected at large distances, making them valuable tools for observational cosmology. Recently, much work has been done on the effects of these objects on the intergalactic medium, particularly in galaxy groups and clusters.

Cassiopeia A (Cas A) is a supernova remnant (SNR) in the constellation Cassiopeia and the brightest extrasolar radio source in the sky at frequencies above 1 GHz.


THE EFFECT OF ATMOSPHERIC RADIATION IN THE MICROWAVE REGION.pdf
The present section contains a discussion of the atmospheric noise level to be expected
for various meteorological conditions and a more detailed discussion of fluctuations of atmospheric
noise. Both large-scale fluctuations due to snow and rain, and small-scale fluctuations
due to water-vapor variations and condensed water are treated.

The absorption of the atmospheric gases at microwave frequencies has been investigated
by van Vleck (1947). The main contribution to the absorption coefficient, a, comes
from the presence of oxygen and water vapor in the atmosphere. The corresponding
radiation temperature from the atmosphere has been studied by Hogg (1959) , among others.
The latter author considered the brightness noise temperature from a standard atmosphere
having a water-vapor content of 10 grams/m3
 at ground level, and also from a humid atmosphere
with 20 grams/m3
. The temperature profile was assumed to be a linear function
of height. The radiation temperature from the total atmosphere is
 see the equation on pdf page 8, Tb as a function of height

where a and T are the absorption coefficient and temperature at the height h. In Figure
5 we have replotted some of the results published by Hogg. The antenna noise temperature
is assumed to be equal to the brightness temperature of the sky (assuming only atmospheric
contribution) , and the antenna temperature is given for different zenith angles for three different frequencies
(0.5, 2, and 10 K.Mc). In addition, for the highest frequency, the effect
of increasing the water-vapor content from 10 to 20 grams/m3
 is indicated.
 
As was pointed out in section I, the noise temperature of the atmosphere directly deteriorates
the sensitivity of a radiometer system because the antenna noise is added to the
system temperature. As Hogg (1959) pointed out, this effect may be quite serious, in
particular for low-noise receiving systems. In order to show what can be gained by using
an observing station at a high altitude, Figure 6 shows the antenna temperature as a function
of observing wavelength for the zenith direction for different altitudes of the observing
site. The model used for this computation was similar to the one used by Hogg. The
barometric, pressure was assumed to vary with height according to an exponential law, the
temperature profile was assumed linear and the water-vapor content was assumed linear
(p= 5 gram/m3
 at h = 0 km and p= 0 at h = 5 km).
From Figure 6 we can see that for an observing st

From Figure 6 we can see that for an observing station at an altitude of 2 km, the noise
temperature is 1.3 °K at 3 cm wavelength, or 43 per cent of the corresponding noise temperature
for a station at sea level. The result from observing at a higher altitude is mainly
to reduce the contribution of the water-vapor content. This is, of course, due to the height
profile we have chosen, which assumes no water-vapor contribution over /10 = 5 km. In
practice, the water-vapor height profile may be more rapidly decreasing than the linear
profile. The assumption of no water vapor above 5 km is, however, a good approximation.

We shall next turn to consider the effect of water in condensed form in the atmosphere,
where we shall be concerned with the effect of rain, snow, and condensed water in clouds.

Precision Measurement of Antenna System Noise Using Radio Stars.pdf
this paper talks about the accuracy of measurements, but antenna gains are large 51 and 65 dB.
3) Atmospheric Effects: The atmospheric effects fall
roughly into three categories; absorptive attenuation, diffusive
attenuation, and refractive attenuation. These effects are small
enough in the frequency range of 1-10 GHz that simple approximate
algorithms for the losses, based only on local temperature,
humidity, and the site elevation can be used [43].

# talk about what models are used

ITU is the United Nations specialized agency for information and communication technologies – ICTs.  
We allocate global radio spectrum and satellite orbits, develop the technical standards that ensure networks and technologies seamlessly interconnect, and strive to improve access to ICTs to underserved communities worldwide.

The International Telecommunication Union (ITU; French: Union Internationale des Télécommunications (UIT)), originally the International Telegraph Union (French: Union Télégraphique Internationale), is a specialized agency of the United Nations (UN) that is responsible for issues that concern information and communication technologies.

Ref:
P Series, Radiowave propagation Recommendation ITU-R P.372-13, (09/2016)


The maximum galactic noise for narrow
beam antennas is shown via a dashed curve in Fig. 3.

what is scintillation fading?  

See equation 11 for formulat to estimate Tsky.
When the surface temperature Ts (K) is known, the mean radiating temperature, Tmr, may be estimated for clear and cloudy weather as:  

$T_{mr} = 37.34+0.81T_s$  
Tmr: atmospheric mean radiating temperature (K).  
Ts: surface temperature  (K)  

This is for elevation angles of what???  
In the absence of local data an atmospheric mean radiating temperature, Tmr, of 275 K may be used
for clear and rainy weather.

A radiative transfer study including cloud effects has been carried out in the United States of
America. Zenith brightness temperatures have been computed from meteorological data for a
typical year selected from a database of 15 years for each of 15 locations. Results from two United
States locations, Yuma, Arizona (5.5 cm annual rainfall) and New York City (98.5 cm annual
rainfall) are given in Figs 6a) and 6b) for five different frequencies.  

this section talks about space stations, but somewhat applicable to airboard platforms looing down.  

4.2 Radio noise due to the Earth’s atmosphere and the Earth’s surface for space stations
The brightness temperature of the Earth’s surface as seen from a particular nadir angle may be
calculated using the radiative transfer equation describing the reflection of downwelling
atmospheric radiation and the emission of radiation by the Earth’s surface.




# Noise from atmospheric gases and the earth’s surface
Noise from individual sources such as the Sun, atmospheric gases, the Earth’s surface, etc., are usually given in terms of a brightness temperature, Tb. The antenna temperature, Ta, is the convolution of the antenna pattern and the brightness temperature of the sky and ground.  

## Sky brightness temperature from Rec. ITU-R P.372-13, Figure 5
Figure 5 shows the brightness temperature of the atmosphere for a ground-based receiver excluding the cosmic noise contribution of 2.7 K or other extra-terrestrial sources for frequencies between 1 and 60 GHz. The curves are calculated using a radiative transfer program for seven different elevation angles and an average atmosphere (7.5 g surface water vapour density, surface temperature of 288 K, and a scale height of 2 km for water vapour). The “U.S. Standard Atmosphere, 1976” is used for the dry atmosphere. A typical water vapour contribution is added above the tropopause.


# Man-made noise
For man-made noise this Recommendation gives the external noise figure. That is, the component of the noise which has a Gaussian distribution. Man-made noise often has an impulsive component and this may be important in affecting the performance of radio systems and networks.  
**not included in the analysis**  

5 Man-made noise
Median values of man-made noise power1 for a number of environments are shown in Fig. 10. 
Note that equation (13) is valid
in the range 0.3 to 250 MHz 

The ITU recomendation for man made noise covers frequencies below 300 MHz.

# Brightness temperature due to extra-terrestrial sources
As a general rule, for communications below 2 GHz, one needs to be concerned with the Sun and the galaxy (the Milky Way), which appears as a broad belt of strong emission.  

Above 2 GHz, one need consider only the Sun and a few very strong non-thermal sources such as Cassiopeia A, Cygnus A and X and the Crab nebula since the cosmic background contributes 2.7 K only and the Milky Way appears as a narrow zone of somewhat enhanced intensity.  

The brightness
temperature range for the common extra-terrestrial noise sources in the frequency range 0.1 to 100 GHz is illustrated in Fig. 12.

plot is log-log format  
Sun and moon: diameter ~ 0.5°
A: quiet Sun, various points from 1 to 10 GHz  
B: Moon, horizontal line from 1 to 100 GHz at 200K  
C: range of galactic noise  
C upper: linear on log-log scale, end points are .1GHz to 1.5GHz, 8000K to 3K  
C lower: linear on log-log scale, end points are .1GHz to 1.5GHz, 300K to 3K  
D: cosmic background, horizontal line at 3K  


Cassiopeia A: Cassiopeia A (Cas A) is a supernova remnant (SNR) in the constellation Cassiopeia and the brightest extrasolar radio source in the sky at frequencies above 1 GHz. The supernova occurred approximately 11,000 light-years (3.4 kpc) away within the Milky Way.[2][3] The expanding cloud of material left over from the supernova now appears approximately 10 light-years (3 pc) across from Earth's perspective. In wavelengths of visible light, it has been seen with amateur telescopes down to 234mm (9.25 in) with filters.[4]  

Cas A was among the first discrete astronomical radio sources found. Its discovery was reported in 1948 by Martin Ryle and Francis Graham-Smith, astronomers at Cambridge, based on observations with the Long Michelson Interferometer.[6] The optical component was first identified in 1950.[7]

Cas A is 3C461 in the Third Cambridge Catalogue of Radio Sources and G111.7-2.1 in the Green Catalog of Supernova Remnants.

Cas A had a flux density of 2720 ± 50 Jy at 1 GHz in 1980.[9] Because the supernova remnant is cooling, its flux density is decreasing. At 1 GHz, its flux density is decreasing at a rate of 0.97 ± 0.04 percent per year.[9] This decrease means that, at frequencies below 1 GHz, Cas A is now less intense than Cygnus A. Cas A is still the brightest extrasolar radio source in the sky at frequencies above 1 GHz.

Ref 9:  
Title: The absolute spectrum of CAS A - an accurate flux density scale and a set of secondary calibrators
Authors: Baars, J. W. M., Genzel, R., Pauliny-Toth, I. I. K., & Witzel, A.
Journal: Astronomy and Astrophysics, vol. 61, no. 1, Oct. 1977, p. 99-106.

Title:	
The absolute spectrum of CAS A - an accurate flux density scale and a set of secondary calibrators
Authors:	
Baars, J. W. M.; Genzel, R.; Pauliny-Toth, I. I. K.; Witzel, A.
Affiliation:	
AA(Max-Planck-Institut für Radioastronomie, Bonn, Germany), AB(Max-Planck-Institut für Radioastronomie, Bonn, Germany), AC(Max-Planck-Institut für Radioastronomie, Bonn, Germany), AD(Max-Planck-Institut für Radioastronomie, Bonn, Germany)
Publication:	
Astronomy and Astrophysics, vol. 61, no. 1, Oct. 1977, p. 99-106. (A&A Homepage)



Cygnus A and X:  
https://en.wikipedia.org/wiki/Cygnus_A  
Cygnus A (3C 405) is a radio galaxy, and one of the strongest radio sources in the sky. It was discovered by Grote Reber in 1939. In 1951, Cygnus A, along with Cassiopeia A, and Puppis A were the first "radio stars" identified with an optical source. Of these, Cygnus A became the first radio galaxy; the other two being nebulae inside the Milky Way.[4] In 1953 Roger Jennison and M K Das Gupta showed it to be a double source.[5] Like all radio galaxies, it contains an active galactic nucleus. The super massive black hole at the core has a mass of (2.5±0.7)×109 M☉.[3]

Images of the galaxy in the radio portion of the electromagnetic spectrum show two jets protruding in opposite directions from the galaxy's center. These jets extend many times the width of the portion of the host galaxy which emits radiation at visible wavelengths.[6] At the ends of the jets are two lobes with "hot spots" of more intense radiation at their edges. These hot spots are formed when material from the jets collides with the surrounding intergalactic medium.[7]

In 2016, a radio transient was discovered 460 parsecs away from the center of Cygnus A. Between 1989 and 2016, the object, cospatial with a previously-known infrared source, exhibited at least an eightfold increase in radio flux density, with comparable luminosity to the brightest known supernova. Due to the lack of measurements in the intervening years, the rate of brightening is unknown, but the object has remained at a relatively constant flux density since its discovery. The data are consistent with a second supermassive black hole orbiting the primary object, with the secondary having undergone a rapid accretion rate increase. The inferred orbital timescale is of the same order as the activity of the primary source, suggesting the secondary may be perturbing the primary and causing the outflows.[8]

https://en.wikipedia.org/wiki/Cygnus_X-1  
Cygnus X-1 (abbreviated Cyg X-1)[12] is a galactic X-ray source in the constellation Cygnus, and the first such source widely accepted to be a black hole.[13][14] It was discovered in 1964 during a rocket flight and is one of the strongest X-ray sources seen from Earth, producing a peak X-ray flux density of 2.3×10−23 Wm−2 Hz−1 (2.3×103 Jansky).[15][16] It remains among the most studied astronomical objects in its class. The compact object is now estimated to have a mass about 14.8 times the mass of the Sun[7] and has been shown to be too small to be any known kind of normal star, or other likely object besides a black hole. If so, the radius of its event horizon has 300 km "as upper bound to the linear dimension of the source region" of occasional X-ray bursts lasting only for about 1 ms.[17]

Cygnus X-1 belongs to a high-mass X-ray binary system, located about 6,070 light years from the Sun, that includes a blue supergiant variable star designated HDE 226868[18] which it orbits at about 0.2 AU, or 20% of the distance from the Earth to the Sun. A stellar wind from the star provides material for an accretion disk around the X-ray source.[19] Matter in the inner disk is heated to millions of degrees, generating the observed X-rays.[20][21] A pair of jets, arranged perpendicular to the disk, are carrying part of the energy of the infalling material away into interstellar space.[22]

This system may belong to a stellar association called Cygnus OB3, which would mean that Cygnus X-1 is about five million years old and formed from a progenitor star that had more than 40 solar masses. The majority of the star's mass was shed, most likely as a stellar wind. If this star had then exploded as a supernova, the resulting force would most likely have ejected the remnant from the system. Hence the star may have instead collapsed directly into a black hole.[11]

Cygnus X-1 was the subject of a friendly scientific wager between physicists Stephen Hawking and Kip Thorne in 1974, with Hawking betting that it was not a black hole. He conceded the bet in 1990 after observational data had strengthened the case that there was indeed a black hole in the system. This hypothesis has not been confirmed due to a lack of direct observation but has generally been accepted from indirect evidence.[23]

Crab nebula:  
https://en.wikipedia.org/wiki/Crab_Nebula
The Crab Nebula (catalogue designations M1, NGC 1952, Taurus A) is a supernova remnant in the constellation of Taurus. The now-current name is due to William Parsons, who observed the object in 1840 using a 36-inch telescope and produced a drawing that looked somewhat like a crab.[5] Corresponding to a bright supernova recorded by Chinese astronomers in 1054, the nebula was observed later by English astronomer John Bevis in 1731. The nebula was the first astronomical object identified with a historical supernova explosion.

At an apparent magnitude of 8.4, comparable to that of Saturn's moon Titan, it is not visible to the naked eye but can be made out using binoculars under favourable conditions. The nebula lies in the Perseus Arm of the Milky Way galaxy, at a distance of about 2.0 kiloparsecs (6,500 ly) from Earth. It has a diameter of 3.4 parsecs (11 ly), corresponding to an apparent diameter of some 7 arcminutes, and is expanding at a rate of about 1,500 kilometres per second (930 mi/s), or 0.5% of the speed of light.

At the center of the nebula lies the Crab Pulsar, a neutron star 28–30 kilometres (17–19 mi) across with a spin rate of 30.2 times per second,[6] which emits pulses of radiation from gamma rays to radio waves. At X-ray and gamma ray energies above 30 keV, the Crab Nebula is generally the brightest persistent source in the sky, with measured flux extending to above 10 TeV. The nebula's radiation allows for the detailed studying of celestial bodies that occult it. In the 1950s and 1960s, the Sun's corona was mapped from observations of the Crab Nebula's radio waves passing through it, and in 2003, the thickness of the atmosphere of Saturn's moon Titan was measured as it blocked out X-rays from the nebula.

The inner part of the nebula is a much smaller pulsar wind nebula that appears as a shell surrounding the pulsar. Some sources consider the Crab Nebula to be an example of both a pulsar wind nebula as well as a supernova remnant,[7] while others separate the two phenomena based on the different sources of energy production and behaviour.[4] For the Crab Nebula, the divisions are superficial but remain meaningful to researchers and their lines of study

See figure 14 for other celestial radio sources.  12 shown in the figure
Third Cambridge Catalogue of Radio Sources  
https://en.wikipedia.org/wiki/Third_Cambridge_Catalogue_of_Radio_Sources  

http://vizier.cfa.harvard.edu/viz-bin/VizieR-3?-source=VIII/1A&-out.max=50&-out.form=HTML  



https://en.wikipedia.org/wiki/3C_273  
https://en.wikipedia.org/wiki/3C_279  

# Man made Satellite
get a list of satellite vs freq.

L- Band (1-2 GHz)
Global Positioning System (GPS) carriers and also satellite mobile phones, such as Iridium; Inmarsat providing communications at sea, land and air; WorldSpace satellite radio.

S-band (2–4 GHz)
Weather radar, surface ship radar, and some communications satellites, especially those of NASA for communication with ISS and Space Shuttle. In May 2009, Inmarsat and Solaris mobile (a joint venture between Eutelsat and Astra) were awarded each a 2×15 MHz portion of the S-band by the European Commission. 

see list  
http://satellitenwelt.de/satfreq_s-band.htm  
http://www.ne.jp/asahi/hamradio/je9pel/satslist.htm  


C-Band (4-8 GHz)
Primarily used for satellite communications, for full-time satellite TV networks or raw satellite feeds. Commonly used in areas that are subject to tropical rainfall, since it is less susceptible to rainfade than Ku band (the original Telstar satellite had a transponder operating in this band, used to relay the first live transatlantic TV signal in 1962).


## Noise temperature of celestial objects
- sun
- moon
- stars

# Atmospheric noise due to lightning
**not included in the analysis**  
data only goes upto 20 and 30 MHz.


# EMI and EMI, telecon, LTE, WiMax

# The combination of noises from several sources
There are occasions where more than one type of noise needs to be considered because two or more
types are of comparable size. This can be true at any frequency, in general, but occurs most often at
HF where atmospheric, man-made and galactic noise can be of comparable size (Fig. 2, 10 MHz,
for example).  






 